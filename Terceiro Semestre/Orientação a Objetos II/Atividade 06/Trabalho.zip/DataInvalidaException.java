public class DataInvalidaException extends Exception{
    public DataInvalidaException(){
        super("Data Invalida! Digite no padrão dd/mm/aaaa");
    }
}
